//
//  ViewController.m
//  弹幕
//
//  Created by ydcy-mini on 16/7/7.
//  Copyright © 2016年 ydcy-mini. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(0, 40, 375, 30);
    [button setTitle:@"开启弹幕" forState:UIControlStateNormal];
    button.titleLabel.textAlignment = NSTextAlignmentCenter;
    button.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:button];
    [button addTarget:self action:@selector(startMove:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)startMove:(UIButton *)btn{

    NSTimer *time = [NSTimer scheduledTimerWithTimeInterval:0.25 target:self selector:@selector(moveLabel) userInfo:nil repeats:YES];

    if (!btn.isSelected) {
        btn.selected = YES;
        [time fire];
        [btn setTitle:@"关闭" forState:UIControlStateNormal];
    }else{
        [btn setTitle:@"开启弹幕" forState:UIControlStateNormal];
        btn.selected = NO;
        [time invalidate];
    }
    NSLog(@"%d",btn.selected);
//    if (btn.isSelected) {
//        <#statements#>
//    }
//
//    [time invalidate];
}

- (void)moveLabel{
    NSArray *ar = @[@"asdfghjk 了",@"立刻就会功夫的撒",@"趣味儿童与 i 哦片",@"破 iu 一天热温泉",@"自行车 v 巴拿马",@"迷你版 v 促销中",@"却啊这些所谓的吃",@"吃的我是想砸钱",@"日方 v 不关痛痒好呢",@"你还要听广播 v 繁荣 ",@"要和你们聚 i 看咯片"];
//    CGFloat screenW = [UIScreen mainScreen].bounds.size.width;
    NSInteger screenH = [UIScreen mainScreen].bounds.size.height;
    NSInteger moveY = rand() % screenH + 70;
    if (moveY > screenH - 30) {
        moveY = screenH - 30;
    }
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, moveY, 100, 30)];
    label.text = ar[arc4random()%ar.count];
    label.textColor = [self returncolor];
    label.font = [UIFont systemFontOfSize:10];
    [self.view addSubview:label];
    [self move:label];
}

- (UIColor *)returncolor
{
    CGFloat r = arc4random_uniform(256) / 255.0;
     CGFloat g = arc4random_uniform(256) / 255.0;
     CGFloat b = arc4random_uniform(256) / 255.0;
    UIColor *color = [UIColor colorWithRed:r green:g blue:b alpha:1];
    return color;
}

- (void)move:(UILabel *)label{

    [UIView animateWithDuration:5 animations:^{

        CGRect frame = label.frame;
        frame.origin.x = [UIScreen mainScreen].bounds.size.width +100;
        label.frame = frame;

    } completion:^(BOOL finished) {
        [label removeFromSuperview];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
