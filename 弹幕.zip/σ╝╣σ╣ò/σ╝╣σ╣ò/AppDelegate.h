//
//  AppDelegate.h
//  弹幕
//
//  Created by ydcy-mini on 16/7/7.
//  Copyright © 2016年 ydcy-mini. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

